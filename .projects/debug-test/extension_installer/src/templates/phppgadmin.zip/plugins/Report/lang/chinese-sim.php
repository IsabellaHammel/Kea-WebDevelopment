<?php

    /**
    * @maintainer He Wei Ping [laser@zhengmai.com.cn]
    */

    // Basic strings
    $plugin_lang['strplugindescription'] = 'Report plugin';

    //Reports
    $plugin_lang['strreport'] = '报表';
    $plugin_lang['strreports'] = '报表';
    $plugin_lang['strshowallreports'] = '显示所有报表';
    $plugin_lang['strnoreports'] = '查无此报表';
    $plugin_lang['strcreatereport'] = '创建报表';
    $plugin_lang['strreportdropped'] = '创建报表完成.';
    $plugin_lang['strreportdroppedbad'] = '删除报表失败';
    $plugin_lang['strconfdropreport'] = '您确定要删除报表"%s"么？';
    $plugin_lang['strreportneedsname'] = '你必须给您的报表命名';
    $plugin_lang['strreportcreated'] = '储存报表完成';
    $plugin_lang['strreportcreatedbad'] = '储存报表失败';
?>
